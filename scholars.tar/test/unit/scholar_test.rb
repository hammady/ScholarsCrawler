require 'test_helper'

class ScholarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
