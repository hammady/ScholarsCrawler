require 'test_helper'

class ScholarsHelperTest < ActionView::TestCase
end
